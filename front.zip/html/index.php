<!doctype html>
<html class="no-js" lang="en">


<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Vision Coin</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Place favicon.ico in the root directory -->
    <link rel="apple-touch-icon" href="images/favicon.png">
    <link rel="shortcut icon" type="image/ico" href="images/favicon.png" />

    <!-- Plugin-CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/themify-icons.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <!-- Main-Stylesheets -->
    <link rel="stylesheet" href="css/space.css">
    <link rel="stylesheet" href="css/theme.css">
    <link rel="stylesheet" href="css/overright.css">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script type="text/javascript">
        $(function () { $(window).scroll(function ()
            {
            	if ($(this).scrollTop() > 70)
                { $('.navbar .navbar-brand img').attr('src','images/icon/v-coin1.png'); }
                 if ($(this).scrollTop() < 70)
                    { $('.navbar .navbar-brand img').attr('src','images/icon/v-coin.png'); }
            });
    });
    </script>
</head>

<body data-spy="scroll" data-target="#mainmenu" data-offset="50">


    <div class="preloade">
        <span><i class="ti-mobile"></i></span>
    </div>

    <!--Header-Area-->
    <header class="blue-bg relative fix" id="home">
        <div class="section-bg overlay-bg angle-bg ripple ">

                <div id="myCarousel" class="carousel slide" data-ride="carousel">
                <!-- Indicators -->
                <!-- Wrapper for slides -->
                <div class="carousel-inner" role="listbox">

                <div class="item active">
                  <img src="images/1.jpg" alt="" width="1280" height="800">

                </div>
                <div class="item">
                  <img src="images/2.jpg" alt="" width="1280" height="800">
                </div>

                </div>
                <!-- Left and right controls -->

                </div>

        </div>
        <!--Mainmenu-->
        <nav class="navbar navbar-default mainmenu-area navbar-fixed-top" data-spy="affix" data-offset-top="60">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" data-toggle="collapse" class="navbar-toggle" data-target="#mainmenu">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a href="#" class="navbar-brand">
                        <!--<img src="images/logo.png" alt="">-->
                        <img src="images/icon/v-coin.png" style="width:85px" class="logo_1">

                    </a>
                </div>
                <div class="collapse navbar-collapse navbar-right" id="mainmenu">
                    <ul class="nav navbar-nav">
                        <li><a href="#home" data-toggle="collapse"  data-target="#mainmenu">Home</a></li>
                        <li><a href="#work" data-toggle="collapse"  data-target="#mainmenu">Work</a></li>
                       <li><a href="#client" data-toggle="collapse"  data-target="#mainmenu">About</a></li>
		  <li><a href="#feature" data-toggle="collapse"  data-target="#mainmenu">Features</a></li>

		 <li ><a href="wallet" >Wallet </a></li>
                 <li ><a href="http://v-coin.io:3001">Explorer </a></li>
                  <li><a href="#contact" data-toggle="collapse"  data-target="#mainmenu">Contact</a></li>
		  <li><a href="javascript:;">1 VCN = <span id="rate1" style="color:#fff !important;"></span> BTC</a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <!--Mainmenu/-->
        <div class="space-100"></div>
        <div class="space-20 hidden-xs"></div>
        <!--Header-Text-->
        <div class="container text-white">
            <div class="row text-center">
                <div class="col-xs-12 col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
                    <div class="space-40"></div>
                    <div class="space-100"></div>
                    <h2>Vision Coin is an open source peer-to-peer digital currency<br> favored by Vision Coin worldwide.</h2>
                    <div class="space-10"></div>
                    <p style="margin: 0 0 10px;line-height: 1.7em;opacity: 10;font-size: 14.5px;">Vision Coin brings sound money to the world, fulfilling the original promise of Bitcoin as "Peer-to-Peer Electronic Cash". Merchants and users are empowered with low fees and reliable confirmations.</p>
                    <div class="space-20"></div>

                    <div class="space-100"></div>
                </div>
            </div>
            <div class="space-80"></div>
        </div>
        <!--Header-Text/-->
    </header>
    <!--Header-Area/-->
    <section>
        <div class="space-80"></div>
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-md-4 wow fadeInUp" data-wow-delay="0.2s">
                    <div class="well well-hover text-center">
                        <p class="md-icon"><span class="ti-bolt-alt"></span></p>
                        <div class="space-10"></div>
                        <h5 class="text-uppercase">Fast</h5>
                        <p>Transact in seconds. Get confirmed in minutes.</p>
                    </div>
                </div>
                <div class="col-xs-12 col-md-4 wow fadeInUp" data-wow-delay="0.4s">
                    <div class="well well-hover text-center">
                        <p class="md-icon"><span class="ti-thumb-up"></span></p>
                        <div class="space-10"></div>
                        <h5 class="text-uppercase">Reliable</h5>
                        <p>A network that runs without congestion.</p>
                    </div>
                </div>
                <div class="col-xs-12 col-md-4 wow fadeInUp" data-wow-delay="0.6s">
                    <div class="well well-hover text-center">
                        <p class="md-icon"><span class="ti-arrow-down"></span></p>
                        <div class="space-10"></div>
                        <h5 class="text-uppercase">Low Fees</h5>
                        <p>Send money globally for pennies.</p>
                    </div>
					</div>
                 </div>
                 <div class="row">
				<div class="col-xs-12 col-md-4 wow fadeInUp" data-wow-delay="0.2s">
                    <div class="well well-hover text-center">
                        <p class="md-icon"><span class="ti-check"></span></p>
                        <div class="space-10"></div>
                        <h5 class="text-uppercase">Simple</h5>
                        <p>Easy to use. No hassles.</p>
                    </div>
                </div>
				<div class="col-xs-12 col-md-4 wow fadeInUp" data-wow-delay="0.2s">
                    <div class="well well-hover text-center">
                        <p class="md-icon"><span class="ti-package"></span></p>
                        <div class="space-10"></div>
                        <h5 class="text-uppercase">Stable</h5>
                        <p>A payment system that's a proven store of value.</p>
                    </div>
                </div>
				<div class="col-xs-12 col-md-4 wow fadeInUp" data-wow-delay="0.2s">
                    <div class="well well-hover text-center">
                        <p class="md-icon"><span class="ti-lock"></span></p>
                        <div class="space-10"></div>
                        <h5 class="text-uppercase">Secure</h5>
                        <p>World's most robust blockchain technology.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="space-80"></div>

    </section>
    <!--Work-Section-->
    <section class="gray-bg" id="work">
        <div class="space-80"></div>
        <div class="container">
            <div class="row wow fadeInUp">
                <div class="col-xs-12 col-md-6 col-md-offset-3 text-center">
                    <h3 class="text-uppercase">How does it work?</h3>
                    <p>To start earning enough, make your investment in Vision coin (VCN) by registration on Visionex.io exchange.</p>
                </div>
            </div>
            <div class="space-60"></div>
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-3 text-center wow fadeInUp" data-wow-delay="0.2s">
                    <div class="hover-shadow">
                        <div class="space-60">
                            <img src="images/icon/am.png" alt="">
                        </div>
                        <div class="space-20"></div>
                        <h5 class="text-uppercase">Register.</h5>

                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-3 text-center wow fadeInUp" data-wow-delay="0.4s">
                    <div class="hover-shadow">
                        <div class="space-60">
                            <img src="images/icon/is.png" alt="">
                        </div>
                        <div class="space-20"></div>
                        <h5 class="text-uppercase">Invest.</h5>

                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-3 text-center wow fadeInUp" data-wow-delay="0.6s">
                    <div class="hover-shadow">
                        <div class="space-60">
                            <img src="images/icon/user1.png" alt="">
                        </div>
                        <div class="space-20"></div>
                        <h5 class="text-uppercase">Real Time Trading.</h5>

                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-3 text-center wow fadeInUp" data-wow-delay="0.8s">
                    <div class="hover-shadow">
                        <div class="space-60">
                            <img src="images/icon/user%20(2).png" alt="">
                        </div>
                        <div class="space-20"></div>
                        <h5 class="text-uppercase">Fast Profit Withdrawal.</h5>

                    </div>
                </div>
            </div>
		</div>
	</section>
    <!--Feature-Section-->

    <!--Screenshot-Section-->

    <!--Screenshot-Section/-->
    <!--Team-Section-->

    <!--Team-Section/-->
    <!--Client-Section-->
    <section id="client">
        <div class="space-80"></div>
        <div class="container">
            <div class="row wow fadeInUp">
                <div class="col-xs-12 col-md-8 col-md-offset-2 text-center">
                    <div class="well well-lg">
                        <div class="client-details-content">
                            <div class="client_details">
                                <div class="item">
                                    <h3>About</h3>

                                    <q>Vision Coin uses peer-to-peer technology to operate with no central authority or banks; managing transactions and the issuing of bitcoins is carried out collectively by the network. Vision Coin is open-source; its designed for public, nobody owns or controls Vision Coin and everyone can take part.</q>
                                </div>




                                <div class="item">
                                    <h3>About</h3>

                                    <q>Vision Coin uses peer-to-peer technology to operate with no central authority or banks; managing transactions and the issuing of bitcoins is carried out collectively by the network. Vision Coin is open-source; its designed for public, nobody owns or controls Vision Coin and everyone can take part.</q>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

		</div>
       <br>
    </section>
    <!--Client-Section-->
	<section>
		 <div class="container" id="feature">
        <div class="space-80"></div>

        <div class="container">
			<div class="row">
				<div class="col-xs-12 col-md-6 col-md-offset-3 text-center">
                    <h3 class="text-uppercase">Coin Specifications</h3>
                    </div><br>
                <div class="col-xs-12 col-md-4 wow fadeInUp" data-wow-delay="0.2s">

                    <div class="well well-hover text-center">

                        <p class="md-icon"><span class="ti-stats-up"></span></p>
                        <div class="space-10"></div>
                        <h5 class="text-uppercase">Coin Max Supply</h5>
                        <p>Total supply of VCN is 1000 M.</p>
                    </div>
                </div>
                <div class="col-xs-12 col-md-4 wow fadeInUp" data-wow-delay="0.4s">
                    <div class="well well-hover text-center">
                        <p class="md-icon"><span class="ti-alarm-clock"></span></p>
                        <div class="space-10"></div>
                        <h5 class="text-uppercase">Coin Block Time</h5>
                        <p>Every block of VCN will be formed in 5 Min.</p>
                    </div>
                </div>
                <div class="col-xs-12 col-md-4 wow fadeInUp" data-wow-delay="0.6s">
                    <div class="well well-hover text-center">
                        <p class="md-icon"><span class="ti-infinite"></span></p>
                        <div class="space-10"></div>
                        <h5 class="text-uppercase">Max Block Size</h5>
                        <p>Max block size of VCN is equal to Bitcoin cash that is 8 MB.</p>
                    </div>
					</div>
                </div>
                <div class="row">
				<div class="col-xs-12 col-md-4 wow fadeInUp" data-wow-delay="0.2s">
                    <div class="well well-hover text-center">
                        <p class="md-icon"><span class="ti-cloud-down"></span></p>
                        <div class="space-10"></div>
                        <h5 class="text-uppercase">Coin Algorithm</h5>
                        <p>We are using X11 algorithm for VCN.</p>
                    </div>
                </div>
				<div class="col-xs-12 col-md-4 wow fadeInUp" data-wow-delay="0.2s">
                    <div class="well well-hover text-center">
                        <p class="md-icon"><span class="ti-pulse"></span></p>
                        <div class="space-10"></div>
                        <h5 class="text-uppercase">Coin Difficulty Retargeting Algorithm</h5>
                        <p>Kimoto gravity well.</p>
                    </div>
                </div>
				<div class="col-xs-12 col-md-4 wow fadeInUp" data-wow-delay="0.2s">
                    <div class="well well-hover text-center">
                        <p class="md-icon"><span class="ti-stats-down"></span></p>
                        <div class="space-10"></div>
                        <h5 class="text-uppercase">Soft Block Size</h5>
                        <p>soft block size of VCN is 2 MB.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="space-80"></div>

    </section>
    <!--Price-section-->

    <!--Price-section/-->
    <!--Question-section-->

    <!--Question-section/-->
    <!--Download-Section-->
    <section class="relative fix">
        <div class="space-80"></div>
        <div class="section-bg overlay-bg">
            <img src="images/top.png" alt="">
        </div>
        <div class="container">
            <div class="row wow fadeInUp">
                <div class="col-xs-12 col-md-6 col-md-offset-3 text-center text-white">
                    <h3 class="text-uppercase">Getting started with Vision Coin</h3>
                    <p>Using Vision Coin to pay and get paid is easy and accessible to everyone.</p>
                </div>
            </div>
            <div class="space-60"></div>
            <div class="row text-white wow fadeInUp">
                <div class="col-xs-12 col-sm-4">


                </div>
                <div class="col-xs-12 col-sm-4">
                    <a href="https://v-coin.io/wallet/" class="big-button aligncenter">
                        <span class="big-button-icon">
                            <span class="ti-android"></span>
                        </span>
                        <span>Getting started with Vision Coin</span>
                        <br>

                    </a>
                    <div class="space-10"></div>
                </div>

            </div>
        </div>
        <div class="space-80"></div>
    </section>
    
    <div id="contact" style="margin-top:6.5%"></div>
<!--    <div id="maps"></div>
<div><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15282581.374688132!2d73.70173776222835!3d20.74678237619792!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30635ff06b92b791%3A0xd78c4fa1854213a6!2sIndia!5e0!3m2!1sen!2sin!4v1516691223258"  frameborder="0" style="border:0" allowfullscreen></iframe></div>-->
    <!--Map/-->
    <!--Footer-area-->
    <footer class="black-bg">
        <div class="container">
            <div class="row">
                <div class="offset-top">
                    <div class="col-xs-12 col-md-6 wow fadeInUp" data-wow-delay="0.2s">
                        <div class="well well-lg">
                            <h3>Get in Touch</h3>
				<?php
if(isset($_REQUEST['msg']))
{
	if($_REQUEST['msg']=="y")

{
	?>
<h3 style="color:green;">Your request has been sent successfully.</h3>
	<?php
header('Refresh:3;url=index.php');
}
	if($_REQUEST['msg']=="n")
{
	?>
<h3 style="color:red;">Error occurred while sending your request!!!</h3>
	<?php
header('Refresh:3;url=index.php');
}
}
				?>
                            <div class="space-20"></div>
                            <form action="contact_form.php"  method="post">
                                <div class="row">
                                    <div class="col-xs-12 col-sm-6">
                                        <div class="form-group">
                                            <label for="form-name" class="sr-only">First Name</label>
                                            <input id="name" class="form-control" type="text" placeholder="First Name*" name="first_name" id="first_name" required>
                                        </div>
                                        <div class="space-10"></div>
                                    </div>
                                    <div class="col-xs-12 col-sm-6">
                                        <div class="form-group">
                                            <label for="form-email" class="sr-only">Last Name</label>
                                             <input type="text" class="form-control"  placeholder="Last Name*" name="last_name" id="last_name"  required>
                                        </div>
                                        <div class="space-10"></div>
                                    </div>
                                    <div class="col-xs-12">
                                        <div class="form-group">
                                            <label for="form-subject" class="sr-only">Email</label>
                                             <input type="email" class="form-control"  placeholder="Email*" name="email" id="email"  required>
                                        </div>
                                        <div class="space-10"></div>
                                    </div>
                                    <div class="col-xs-12">
                                        <div class="form-group">
                                            <label for="form-message" class="sr-only">comment</label>

                                            <textarea  id="message" class="form-control" class="input-message" placeholder="Comment*"  required rows="6" name="message"></textarea>
                                        </div>
                                       <br>
                                       <!-- <input class="btn btn-link no-round text-uppercase" name="submit" type="submit" value="Send"> -->
<input type="submit" name="submit" value="Send" class="btn btn-success" style="background-color:#37cdc7;">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-xs-12 col-md-6 wow fadeInUp" data-wow-delay="0.4s">
                        <div class="well well-lg">
                            <h3>Support</h3>
                            <div class="space-20"></div>
                            <p style="text-align: justify;">Vision Coin can be easily bought and sell from the exchange Visionex.io. Where you get the real-time trading. You can buy/sell Vision Coin in BTC market, BCH market & LTC market on Visionex.io. If you have an enquiry related to Vision Coin, you can send the message from the website or you can directly connect with our dedicated team on the following email.</p>
                            <div class="space-25"></div>
                            <table class="table">
                                <tbody>
                                    <tr>
                                        <td>
                                            <div class="border-icon sm"><span class="ti-email"></span></div>
                                        </td>
                                        <td>
                                            <a href="mailto:support@V-coin.io">support@v-coin.io</a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="border-icon sm"><span class="ti-email"></span></div>
                                        </td>
                                        <td>
                                            <a href="mailto:info@V-coin.io">info@v-coin.io</a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="border-icon sm"><span class="ti-email"></span></div>
                                        </td>
                                        <td>
                                            <a href="mailto:Contactus@V-coin.io">Contactus@v-coin.io</a>
                                        </td>

                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row text-white wow fadeIn">
                <div class="col-xs-12 text-center">

                    <div class="space-20"></div>
                    <p>©2018 V-Coin copyright Reserved.</p>
                </div>
            </div>
            <div class="space-20"></div>
        </div>
    </footer>
    <!--Footer-area-->

    <!--Vendor JS-->
    <script src="js/vendor/jquery-1.12.4.min.js"></script>
	<script>

$(document).ready(function() {
  setTimeout(function(){ $(".preloade").hide(); }, 5000);
        currentvcnrate();
});
   function currentvcnrate()
    {
       $.post('ajax.php',{
      	q:'currentvcnrate'
          
          },
          function(data){

          $('#rate1').html(data);
        
          }
        ); 
    }

      

</script>
    <script src="js/vendor/bootstrap.min.js"></script>
    <!--Plugin JS-->
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/scrollUp.min.js"></script>
    <script src="js/magnific-popup.min.js"></script>
    <script src="js/ripples-min.js"></script>
    <script src="js/contact-form.js"></script>
    <script src="js/spectragram.min.js"></script>
    <script src="js/ajaxchimp.js"></script>
    <script src="js/wow.min.js"></script>
    <!-- <script src="js/plugins.js"></script> -->
    <!--Active JS-->
    <script src="js/main.js"></script>
    <!--Maps JS-->

   <!-- <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBTS_KEDfHXYBslFTI_qPJIybDP3eceE-A&amp;sensor=false"></script>
    <script src="js/maps.js"></script>-->
</body>

</html>
