 <?php
print_r($_POST);

$fname=trim($_POST['first_name']);
$lname=trim($_POST['last_name']);
$email=trim($_POST['email']);
$message=trim($_POST['message']);

$to =$email;
$subject = "Contact with vision coin";

$template = '<div style="padding:50px;">Hello ' . $fname." ".$lname . ',<br/>';
$template .='<br/>Thank you...! For Contacting Us.<br/><br/>';
$template .='Name:' . $fname." ".$lname . '<br/>';
$template .= 'Email:' . $email . '<br/>';
$template .= 'Message:' . $_POST['message'] . '<br/><br/>';
$template .='This is a Contact Confirmation mail.';
$template .='<br/>';
$template .='We Will contact You as soon as possible .</div>';
 //Always set content-type when sending HTML email
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= 'From: <visionx@gmail.com>' . "\r\n";
$headers .= 'Cc: chandu2013pal@gmail.com' . "\r\n";

$sendmessage = "<div style=\"background-color:#7E7E7E; color:white;\">" . $template . "</div>";

$send=mail($to,$subject,$sendmessage,$headers);
if($send){
    header("Location:index.php?msg=y#contact");
    }
    else{
        header("Location:index.php?msg=n#contact");
    }
?>
