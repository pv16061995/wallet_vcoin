<?php

if($_POST['q']=='currentvcnrate')
{
currentvcnrate();
}
function currentvcnrate()
    {
   

        $detail=file_get_contents("https://cex.io/api/ticker/BTC/USD");
        $data=json_decode($detail);
        $vcn_rate=$data->ask;
        $vcn = 1/$vcn_rate;
        print_r(number_format($vcn,8));
    }

?>
