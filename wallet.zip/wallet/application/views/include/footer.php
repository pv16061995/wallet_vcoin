 <!-- footer content -->
        <footer>
          <div class="pull-right"><a href="javascript:;"><?php echo project_name();?></a>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <script src="<?php echo asset_url() ?>css/jquery/dist/jquery.min.js"></script>
    <script src="<?php echo asset_url() ?>css/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="<?php echo asset_url() ?>css/fastclick/lib/fastclick.js"></script>
    <script src="<?php echo asset_url() ?>css/nprogress/nprogress.js"></script>
    <script src="<?php echo asset_url() ?>css/Chart.js/dist/Chart.min.js"></script>
    <script src="<?php echo asset_url() ?>css/gauge.js/dist/gauge.min.js"></script>
    <script src="<?php echo asset_url() ?>css/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <script src="<?php echo asset_url() ?>css/iCheck/icheck.min.js"></script>
    <script src="<?php echo asset_url() ?>css/skycons/skycons.js"></script>
    <script src="<?php echo asset_url() ?>css/Flot/jquery.flot.js"></script>
    <script src="<?php echo asset_url() ?>css/Flot/jquery.flot.pie.js"></script>
    <script src="<?php echo asset_url() ?>css/Flot/jquery.flot.time.js"></script>
    <script src="<?php echo asset_url() ?>css/Flot/jquery.flot.stack.js"></script>
    <script src="<?php echo asset_url() ?>css/Flot/jquery.flot.resize.js"></script>
    <script src="<?php echo asset_url() ?>css/flot.orderbars/js/jquery.flot.orderBars.js"></script>
    <script src="<?php echo asset_url() ?>css/flot-spline/js/jquery.flot.spline.min.js"></script>
    <script src="<?php echo asset_url() ?>css/flot.curvedlines/curvedLines.js"></script>
    <script src="<?php echo asset_url() ?>css/DateJS/build/date.js"></script>
    <script src="<?php echo asset_url() ?>css/jqvmap/dist/jquery.vmap.js"></script>
    <script src="<?php echo asset_url() ?>css/jqvmap/dist/maps/jquery.vmap.world.js"></script>
    <script src="<?php echo asset_url() ?>css/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
    <script src="<?php echo asset_url() ?>css/moment/min/moment.min.js"></script>
    <script src="<?php echo asset_url() ?>css/bootstrap-daterangepicker/daterangepicker.js"></script>
    <script src="<?php echo asset_url() ?>css/build/custom.min.js"></script>
    <script src="<?php echo asset_url() ?>css/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>

    <script src="<?php echo asset_url() ?>css/validation_engine/jquery.validationEngine-en.js"></script>
    <script src="<?php echo asset_url() ?>css/validation_engine/jquery.validationEngine.js"></script>
    
    <script src="<?php echo asset_url() ?>css/google-code-prettify/src/prettify.js"></script>

    <script src="<?php echo asset_url() ?>css/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo asset_url() ?>css/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo asset_url() ?>css/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo asset_url() ?>css/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="<?php echo asset_url() ?>css/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="<?php echo asset_url() ?>css/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo asset_url() ?>css/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo asset_url() ?>css/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="<?php echo asset_url() ?>css/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="<?php echo asset_url() ?>css/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo asset_url() ?>css/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="<?php echo asset_url() ?>css/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
    <script src="<?php echo asset_url() ?>css/jszip/dist/jszip.min.js"></script>
    <script src="<?php echo asset_url() ?>css/pdfmake/build/pdfmake.min.js"></script>
    <script src="<?php echo asset_url() ?>css/pdfmake/build/vfs_fonts.js"></script>

   <!--  
    <script src="<?php echo asset_url() ?>css/pnotify/dist/pnotify.js"></script>
    <script src="<?php echo asset_url() ?>css/pnotify/dist/pnotify.buttons.js"></script>
    <script src="<?php echo asset_url() ?>css/pnotify/dist/pnotify.nonblock.js"></script> -->

	
  </body>
</html>

<style type="text/css">
	.img-circle.profile_img {
    width: 100% !important;
    background: #fff;
    margin-left: 0% !important; 
    z-index: 1000;
    position: inherit;
    margin-top: 0px;  !important;
    border: 1px solid rgba(52,73,94,.44);
    padding: 4px;
}

.img-circle {
   border-radius: 0% !important;
}
</style>