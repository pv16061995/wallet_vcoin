
<?php
function asset_url()
{
   return base_url().'assets/';
}
function logo_url()
{
	return base_url().'assets/images/logo.png';
}

function favicon_url()
{
	return base_url().'assets/images/v-coin-favicon.png';
}
function login_bg()
{
	return base_url().'assets/images/loginbg.jpg';
}

function project_name()
{
	return 'V-Coin Wallet';
}

function wallet_mail()
{
	return 'info@v-coin.io';
}

function sending_mail()
{
	return 'info@v-coin.io';
}

function sending_mail_pass()
{
	return 'vision@123';
}

function admin_url()
{
	return base_url().'admin/';
}

function admin_login_bg()
{
	return base_url().'assets/images/login-bg.jpg';
}




?>